<link href="js/select2/select2.css" rel="stylesheet"/>
<script src="js/select2/select2.js"></script>
<script>
    $(document).ready(function() { $("#packData").select2({ width: 'resolve', placeholder: "Choose a file" }); });
    $(document).ready(function() { $("#glm_intsel").select2({ width: 'resolve' }); });
</script>
