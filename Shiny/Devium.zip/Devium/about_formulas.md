## Radyant - Marketing analytics using Shiny


Version 0.09 (2/17/2013)

By: Vincent Nijs (vnijs at rady.ucsd.edu)

Built using [Shiny](http://www.rstudio.com/shiny/) by [Rstudio](http://www.rstudio.com/)

Dependencies for local use: shiny, shiny-incubator, car, tools, foreign, ggplot2, gridExtra, reshape2, plyr, markdown, R.utils, fGarch, quantmod, psych, rela, arm

Code available on [GitHub](https://github.com/mostly-harmless/radyant)

$\beta_{ij}$
